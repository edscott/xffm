#!/bin/sh
scp * xffm.xfce.org:/home/edscott/htdocs
scp * xffm.sf.net:/home/groups/x/xf/xffm/htdocs
