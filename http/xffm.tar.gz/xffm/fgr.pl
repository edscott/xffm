#!/usr/bin/perl
#
#
sub document;
use webcommon;

$screenshots="";
$version = "0.6.6";
$title = "Fgr Command Find Tool $version";
$documentation="docs/fgr/";
$download = "http://sourceforge.net/project/showfiles.php?group_id=70875&package_id=162860";
$abstract = "The Fgr program is small and simple application to find files and pipe the result to grep in order to refine the search based on content.";
$description ="<br>
<b>Description</b><br><blockquote>
Fgr is the command find tool used by the Xfce desktop environment since 2000. The Xfce GUI front end (xfglob) uses this simple program for all seaching. 
The ability to use the command tool from either a GUI or the command line provides this application with great versatility.
<br></blockquote>
<b>Development</b><br><blockquote>
Fgr first appeared (as glob) in the year 2000 in the xfce3 desktop. With the development of xfce4, fgr was included in the xffm filemanager code. Today fgr has been separated from the Xffm filemanager code. This allows for quick and easy installation in any system. The fgr program does not have any dependencies, except for GNU grep 2.x or higher.<p>
If you want a GUI front-end for the find tool, look into <a href=xffm.html>xfglob4</a> (xfglob4 is one of several GUI's available for the Xffm filemanager).
</blockquote>
";
$news= <<END;
<b>News:</b>
<blockquote> 
<font color=#ff0000>
fgr 0.6.6 released 
</font>(Mar. 13, 2006)<br>
Fixes and removal of unnecessary dependencies.
Japanese translations added.
</blockquote>

<blockquote> 
<font color=#ff0000>
fgr 0.6.1 released 
</font>(Oct. 5, 2005)<br>
Added internationalization and Spanish translations.
</blockquote>
<blockquote> 
<font color=#ff0000>
fgr 0.6.0 released 
</font>(Sep. 5, 2005)
</blockquote>

END

&document($title,$abstract,$description,$download,$documentation,$news,$screenshots);

