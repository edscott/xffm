#!/usr/bin/perl
#
#
sub document;
use webcommon;

$screenshots="<li><a href=screenshots/ class=mbold>Screenshots</a></li>";
$title = "Xtended Function File Management ";
$abstract= "Xtended Function File Management (Xffm) Code Set consists of OpenSource code to enhance filemanagement. It is based on GTK+";
$description="";
$documentation="docs/";
$download = "http://sourceforge.net/project/showfiles.php?group_id=70875";
$news= <<END;
<blockquote>
Xffm Code Set includes:
<ul>
<!--
<li> 
<b> Disk based hashtables: </b>
<a href=http://dbh.sf.net>Libdbh</a>
</li>
-->
<li>
<b> Interprocess communication: </b>
<a href=libtubo.html>Libtubo</a>
</li>
<li> 
<b> Command Search Tool: </b>
<a href=fgr.html>Fgr</a>
</li>
<li> 
<b> Encryption tool: </b>
<a href=scramble.html>Scramble</a>
</li>
<li> 
<b> Graphic differences: </b>
<a href=xfdiff.html>Xfdiff</a>
</li>
<li> 
<b> Graphic execution: </b>
Xffm-run 
</li>
<li> 
<b> Desktop background setting: </b>
Xffm-root 
</li>
<li> 
<b> File management: </b>
<a href=xffm.html>Xffm-GUI</a>
</li>
<ul>
    <li> Desktop GUI </li>
    <li> Spatial GUI </li>
    <li> Treeview GUI </li>
    <li> File Find GUI </li>
</ul>
<li> Xfmime-edit </li>
<li> And the Xffm-plugins: </li>
<ul>
<li> Xfsamba </li>
<li> Xfbook </li>
<li> xffstab </li>
<li> xftrash </li>
<li> xfapps </li>
<li> xfrecent </li>
<li> xffrequent </li>
<li> xflocate </li>
</ul>
</ul>
<br>
</blockquote>
<blockquote>
Foo-Meter (13-03-06):<br>
<ul>
<li>Libtubo  (125)</li>
<li>Xfdiff   (150)</li>
<li>Xfbook   (391)</li>
<li>Xffm     (562)</li>
<li>Xfsamba  (666)</li>
<li> Scramble (986)</li>
</ul>
</blockquote>
    

END

&document($title,$abstract,$description,$download,$documentation,$news,$screenshots);

