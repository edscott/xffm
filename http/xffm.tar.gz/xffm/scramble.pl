#!/usr/bin/perl
#
#
sub document;
use webcommon;

$screenshots="";
$version = "0.2.1";
$title = "Scramble Command Tool $version";
$documentation="docs/scramble/";
$download = "http://sourceforge.net/project/showfiles.php?group_id=70875&package_id=163452";
$abstract = "The Scramble program is small and simple application to encrypt files.";
$description ="<br>
<b>Description</b><br><blockquote>
Scramble is the command find tool used by the Xfce desktop environment. The Xffm filemanager thus uses this program to encrypt and descrypt files upon user request. The application is also used to schred files before deleting.
<br></blockquote>
<b>Development</b><br><blockquote>
The scramble program does not have any dependencies<p>
If you want a GUI front-end for scrambling and unscrambling, look into the <a href=xffm.html>xffm-GUI</a>.
</blockquote>
";
$news= <<END;
<b>News:</b>
<blockquote> 
<font color=#ff0000>
scramble 0.2.1 released 
</font>(Oct. 5, 2005)<br>
Fixed locale settings for internationalization.
</blockquote>
<blockquote> 
<font color=#ff0000>
scramble 0.2.0 released 
</font>(Sep. 12, 2005)
</blockquote>

END

&document($title,$abstract,$description,$download,$documentation,$news,$screenshots);

